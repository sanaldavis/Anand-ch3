def mapi(a):
  b=[i*i for i in a]
  print b

mapi(range(5))
